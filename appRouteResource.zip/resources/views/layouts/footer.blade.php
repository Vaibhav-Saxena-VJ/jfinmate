<!-- Footer -->
    <footer class="sticky-footer bg-black">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <samll><span class="text-body"><a href="#" class="border-bottom text-primary">2024 <i class="far fa-copyright text-white me-1"></i> Jfinserv Consultant</a>, All rights reserved | Developed By <a class="border-bottom text-primary" href="https://jfstechnologies.com">JFS Technologies</a>.</span></samll>
            </div>
        </div>
    </footer>
<!-- End of Footer -->
